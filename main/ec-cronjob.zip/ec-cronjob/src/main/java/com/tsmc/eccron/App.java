package com.tsmc.eccron;

import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.quartz.impl.StdSchedulerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.SimpleScheduleBuilder.simpleSchedule;
import static org.quartz.TriggerBuilder.newTrigger;

public class App {

    public static void main( String[] args ) {
        try {
            // Schedulers are created from Factories
            Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
            scheduler.start();

            Properties prop = new Properties();
            try (InputStream input = App.class.getClassLoader().getResourceAsStream("cron.conf")) {
                // load a properties file
                prop.load(input);
                // get the property value and print it out
                System.out.println(prop.getProperty("ec.cron_list"));

            } catch (IOException ex) {
                ex.printStackTrace();
            }

            /*
             * Scheduling those jobs with Triggers that define what time the jobs should run
             */

            // Defining the job (and tying it to MyJob.class)
//            JobDetail jobDetail = newJob(MyJob.class)
////                .withIdentity("job1", "group1")
//                .build();

            // check https://www.freeformatter.com/cron-expression-generator-quartz.html for the cron format
            String[] cronExps = prop.getProperty("ec.cron_list").toString().split(";");
            int idx =0;
            for(String cronExp: cronExps) {
                JobDetail jobDetail = newJob(MyJob.class)
                .withIdentity("job_"+idx, "group1")
                        .build();

                Trigger trigger = newTrigger()
                        .withIdentity("trigger_"+idx, "group1")
//                        .withSchedule(cronSchedule("0 0/1 * * * ?"))
                        .withSchedule(cronSchedule(cronExp))
                        .forJob(jobDetail)
                        .build();
                scheduler.scheduleJob(jobDetail, trigger);
                idx++;
            }

            // tell scheduler to schedule the job using the trigger


        } catch (SchedulerException e) {
            System.out.println(e.getLocalizedMessage());
        }
    }
}
